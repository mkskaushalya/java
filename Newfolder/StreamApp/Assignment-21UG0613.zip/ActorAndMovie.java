public class ActorAndMovie {

    public String getData(String artistName){
        return "Artist Associated Videos";
    }
    
    public void setData(String artistName, String videoName){
        // Save Associated Data(Send database)
    }
}